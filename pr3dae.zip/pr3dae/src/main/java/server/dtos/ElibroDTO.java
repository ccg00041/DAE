/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.dtos;

import java.util.Date;

/**
 *
 * @author caro cubillo
 */
public class ElibroDTO {

    private String tematica, titulo;
    private Date fechaDePublicacion;
    private int nota;

    public ElibroDTO() {
        tematica = "";
        titulo = "";
        fechaDePublicacion = null;
        nota = 0;
    }

    public ElibroDTO(String titulo) {
        this.titulo = titulo;
    }

    public ElibroDTO(String titulo, int nota) {
        this.titulo = titulo;
        this.nota = nota;
    }

    public ElibroDTO(String tematica, String titulo, Date fechaDePublicacion) {
        this.tematica = tematica;
        this.titulo = titulo;
        this.fechaDePublicacion = fechaDePublicacion;
    }

    /**
     * @return the tematica
     */
    public String getTematica() {
        return tematica;
    }

    /**
     * @param tematica the tematica to set
     */
    public void setTematica(String tematica) {
        this.tematica = tematica;
    }

    /**
     * @return the titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @param titulo the titulo to set
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * @return the fechaDePublicacion
     */
    public Date getFechaDePublicacion() {
        return fechaDePublicacion;
    }

    /**
     * @param fechaDePublicacion the fechaDePublicacion to set
     */
    public void setFechaDePublicacion(Date fechaDePublicacion) {
        this.fechaDePublicacion = fechaDePublicacion;
    }

    /**
     * @return the nota
     */
    public int getNota() {
        return nota;
    }

    /**
     * @param nota the nota to set
     */
    public void setNota(int nota) {
        this.nota = nota;
    }
}
