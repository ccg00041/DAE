/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.dtos;

/**
 *
 * @author caro cubillo
 */
public class UsuarioDTO {

    private String nick, password;
    private boolean esAutor, esRevisor, esEditor;

    public UsuarioDTO() {
        nick = "";
        password = "";
        esAutor = false;
        esRevisor = false;
        esEditor = false;
    }

    public UsuarioDTO(String nick) {
        this.nick = nick;
    }

    public UsuarioDTO(String nick, String password) {
        this.nick = nick;
        this.password = password;
    }

    public UsuarioDTO(String nick, boolean esAutor, boolean esRevisor, boolean esEditor) {
        this.esAutor = esAutor;
        this.esEditor = esEditor;
        this.esRevisor = esRevisor;
        this.nick = nick;
    }

    public UsuarioDTO(String nick, String password, boolean esAutor, boolean esRevisor) {
        this.nick = nick;
        this.password = password;
        this.esAutor = esAutor;
        this.esRevisor = esRevisor;
    }

    /**
     * @return the nick
     */
    public String getNick() {
        return nick;
    }

    /**
     * @param nick the nick to set
     */
    public void setNick(String nick) {
        this.nick = nick;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the esAutor
     */
    public boolean isEsAutor() {
        return esAutor;
    }

    /**
     * @param esAutor the esAutor to set
     */
    public void setEsAutor(boolean esAutor) {
        this.esAutor = esAutor;
    }

    /**
     * @return the esRevisor
     */
    public boolean isEsRevisor() {
        return esRevisor;
    }

    /**
     * @param esRevisor the esRevisor to set
     */
    public void setEsRevisor(boolean esRevisor) {
        this.esRevisor = esRevisor;
    }

    /**
     * @return the esEditor
     */
    public boolean isEsEditor() {
        return esEditor;
    }

    /**
     * @param esEditor the esEditor to set
     */
    public void setEsEditor(boolean esEditor) {
        this.esEditor = esEditor;
    }
}
