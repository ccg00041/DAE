/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.implementations;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;
import org.springframework.web.bind.annotation.RestController;
import server.classes.Usuario;
import server.daos.UsuarioDAO;
import server.dtos.UsuarioDTO;
import server.exceptions.UsuarioYaExiste;
import static server.implementations.AutorServiceImpl.anadirAutor;
import static server.implementations.RevisorServiceImpl.anadirRevisor;
import server.interfaces.UsuarioService;

/**
 *
 * @author Felipe
 */
@Component
@RestController
@RequestMapping
public class UsuarioServiceImpl implements UsuarioService {

    protected static UsuarioDAO usuarioDAO;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    public void setUsuarioDAO(UsuarioDAO usuarioDAO) {
        UsuarioServiceImpl.usuarioDAO = usuarioDAO;
    }

    @Override
    @RequestMapping(value = "/usuario", method = GET, produces = "application/json")
    public UsuarioDTO identifica(Principal usuario) throws Exception {
        User user = (User) UsernamePasswordAuthenticationToken.class.cast(usuario).getPrincipal();
        Collection<String> roles = new ArrayList<>();
        user.getAuthorities().forEach((rol) -> {
            roles.add(rol.getAuthority());
        });
        return new UsuarioDTO(user.getUsername(), roles.contains("ROLE_AUTOR"), roles.contains("ROLE_REVISOR"), roles.contains("ROLE_EDITOR"));
    }

    @Override
    @RequestMapping(value = "/usuario", method = POST, consumes = "application/json")
    public void registro(@RequestBody UsuarioDTO udto) throws Exception {
        if (usuarioDAO.buscar(udto.getNick()) != null) {
            throw new UsuarioYaExiste();
        }
        Usuario usuario = new Usuario();
        usuario.setNick(udto.getNick());
        usuario.setPassword(passwordEncoder.encode(udto.getPassword()));
        usuarioDAO.insertar(usuario);

        if (udto.isEsAutor()) {
            usuario.setEsAutor(true);
            usuarioDAO.actualizar(usuario);
            anadirAutor(usuario);
        }

        if (udto.isEsRevisor()) {
            usuario.setEsRevisor(true);
            usuarioDAO.actualizar(usuario);
            anadirRevisor(usuario);
        }
    }

    public static Usuario getUsuario(String nick) {
        return usuarioDAO.buscar(nick);
    }
}
