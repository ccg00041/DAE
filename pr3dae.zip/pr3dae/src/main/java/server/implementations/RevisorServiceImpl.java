/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.implementations;

import java.security.Principal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import static org.springframework.web.bind.annotation.RequestMethod.POST;
import org.springframework.web.bind.annotation.RestController;
import server.auxs.IndiceDeFecha;
import server.auxs.IndiceDeTamano;
import server.classes.Elibro;
import server.classes.Revisor;
import server.classes.Usuario;
import server.daos.RevisorDAO;
import server.dtos.ElibroDTO;
import server.dtos.RevisorDTO;
import server.exceptions.LibroNoExiste;
import server.exceptions.NotaNoValida;
import static server.implementations.ElibroServiceImpl.insertarNota;
import server.interfaces.RevisorService;

/**
 *
 * @author Felipe
 */
@Component
@RestController
@RequestMapping
public class RevisorServiceImpl implements RevisorService {

    protected static RevisorDAO revisorDAO;

    @Autowired
    public void setRevisorDAO(RevisorDAO revisorDAO) {
        RevisorServiceImpl.revisorDAO = revisorDAO;
    }

    @Override
    @RequestMapping(value = "/revisor/libro", method = POST, consumes = "application/json")
    public void revisarLibro(@RequestBody ElibroDTO eldto, Principal usuario) throws Exception {
        if (eldto.getNota() > 5 || eldto.getNota() < 0) {
            throw new NotaNoValida();
        }

        Elibro libro = new Elibro();
        for (Elibro el : revisorDAO.buscarLibrosEnRevision(usuario.getName())) {
            if (el.getTitulo().equals(eldto.getTitulo())) {
                libro = el;
            }
        }

        if (libro == null) {
            throw new LibroNoExiste();
        }
        insertarNota(libro.getTitulo(), eldto.getNota());
        revisorDAO.eliminarDeEnRevision(libro, usuario.getName());
    }

    public static RevisorDTO[] toDTO(Revisor[] revisores) {
        RevisorDTO[] nuevo = new RevisorDTO[revisores.length];
        for (int i = 0; i < revisores.length; i++) {
            nuevo[i] = new RevisorDTO(revisores[i].getNick());
        }
        return nuevo;
    }

    public static Revisor getRevisor(int index) {
        for (Revisor rev : revisorDAO.buscarTodos()) {
            if (index == 0) {
                return rev;
            }
            index--;
        }
        return null;
    }

    public static void anadirRevisor(Usuario usuario) throws Exception {
        Revisor revisor = new Revisor(usuario);
        revisorDAO.insertar(revisor);
    }

    public static Revisor[] cargarListaDeRevisores(List<IndiceDeTamano> sizes, List<IndiceDeFecha> dates) {
        return revisorDAO.cargarListaDeRevisores(sizes, dates);
    }

    public static boolean insertarAEnRevision(Elibro elibro, String nick) {
        return revisorDAO.insertarAEnRevision(elibro, nick);
    }

    public static void cargarListasDeCandidatos(List<IndiceDeTamano> sizes, List<IndiceDeFecha> dates) {
        revisorDAO.cargarListasDeCandidatos(sizes, dates);
    }

    public static List<Elibro> buscarLibrosEnRevision(String nick) {
        return revisorDAO.buscarLibrosEnRevision(nick);
    }
}
