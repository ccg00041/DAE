/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.implementations;

import java.util.ArrayList;
import static java.util.Arrays.asList;
import java.util.List;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import static org.springframework.web.bind.annotation.RequestMethod.POST;
import org.springframework.web.bind.annotation.RestController;
import server.auxs.IndiceDeFecha;
import server.auxs.IndiceDeTamano;
import server.classes.Editor;
import server.classes.Elibro;
import server.classes.Revisor;
import server.classes.Usuario;
import server.dtos.ElibroDTO;
import server.dtos.RevisorDTO;
import server.exceptions.LibroNoValidable;
import server.exceptions.RevisoresInsuficientes;
import server.exceptions.RevisoresYaAsignados;
import static server.implementations.RevisorServiceImpl.toDTO;
import static server.implementations.ElibroServiceImpl.buscarLibro;
import static server.implementations.ElibroServiceImpl.buscarNotas;
import static server.implementations.ElibroServiceImpl.setEsRevisado;
import static server.implementations.ElibroServiceImpl.setEsValido;
import static server.implementations.ElibroServiceImpl.tieneRevisores;
import static server.implementations.RevisorServiceImpl.cargarListaDeRevisores;
import static server.implementations.RevisorServiceImpl.cargarListasDeCandidatos;
import static server.implementations.RevisorServiceImpl.insertarAEnRevision;
import server.interfaces.EditorService;

/**
 *
 * @author Felipe
 */
@Component
@RestController
@RequestMapping
public class EditorServiceImpl implements EditorService {

    protected static Editor editor;

    @Override
    @RequestMapping(value = "/editor/libro", method = POST, consumes = "application/json")
    public void validarLibro(@RequestBody ElibroDTO eldto) throws Exception {
        Elibro libro = buscarLibro(eldto.getTitulo());
        List<Integer> notas = buscarNotas(eldto.getTitulo());
        if (notas.isEmpty()) {
            throw new LibroNoValidable();
        }

        boolean menorQue2 = (notas.get(0) < 2) || (notas.get(1) < 2) || (notas.get(2) < 2);
        boolean menorQue10 = (notas.get(0) + notas.get(1) + notas.get(2)) < 10;
        if (notas.size() != 3 || menorQue2 || menorQue10) {
            throw new LibroNoValidable();
        }
        setEsValido(libro);
        editor.getLibrosValidados().add(libro);
    }

    @Override
    @RequestMapping(value = "/editor/revisor", method = POST, consumes = "application/json", produces = "application/json")
    public RevisorDTO[] asignarRevisores(@RequestBody ElibroDTO eldto) throws Exception {
        Elibro libro = buscarLibro(eldto.getTitulo());
        if (tieneRevisores(eldto.getTitulo())) {
            throw new RevisoresYaAsignados();
        }

        Revisor[] rsores = obtenerRevisores();
        libro.setRevsDelLibro(new ArrayList<>(asList(rsores)));
        for (Revisor rev : rsores) {
            insertarAEnRevision(libro, rev.getNick());
        }
        setEsRevisado(libro);
        return toDTO(rsores);
    }

    public Revisor[] obtenerRevisores() throws Exception {
        List<IndiceDeFecha> dates = new ArrayList<>();
        List<IndiceDeTamano> sizes = new ArrayList<>();
        cargarListasDeCandidatos(sizes, dates);
        
        if (sizes.size() < 3) {
            throw new RevisoresInsuficientes();
        }
        dates.sort((IndiceDeFecha t, IndiceDeFecha t1) -> t.getFecha().compareTo(t1.getFecha()));
        sizes.sort((IndiceDeTamano t, IndiceDeTamano t1) -> t.getTamano().compareTo(t1.getTamano()));
        return cargarListaDeRevisores(sizes, dates);
    }
    
    public static void anadirEditor(Usuario usuario) {
        Editor ed = new Editor(usuario);
        editor = ed;
    }
}
