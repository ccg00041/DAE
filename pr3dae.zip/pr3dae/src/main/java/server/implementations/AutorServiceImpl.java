/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.implementations;

import java.security.Principal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import static org.springframework.web.bind.annotation.RequestMethod.POST;
import org.springframework.web.bind.annotation.RestController;
import server.classes.Autor;
import server.classes.Elibro;
import server.classes.Usuario;
import server.daos.AutorDAO;
import server.dtos.ElibroDTO;
import static server.implementations.ElibroServiceImpl.anadirLibro;
import server.interfaces.AutorService;

/**
 *
 * @author Felipe
 */
@Component
@RestController
@RequestMapping
public class AutorServiceImpl implements AutorService {

    protected static AutorDAO autorDAO;

    @Autowired
    public void setAutorDAO(AutorDAO autorDAO) {
        AutorServiceImpl.autorDAO = autorDAO;
    }

    @Override
    @RequestMapping(value = "/autor/libro", method = POST, consumes = "application/json")
    public boolean subirLibro(@RequestBody ElibroDTO eldto, Principal usuario) throws Exception {
        Elibro elibro = new Elibro();
        elibro.setAutor(autorDAO.buscar(usuario.getName()).getNombreCompleto());
        elibro.setTematica(eldto.getTematica());
        elibro.setTitulo(eldto.getTitulo());
        elibro.setFechaDePublicacion(eldto.getFechaDePublicacion());

        anadirLibro(elibro);
        return autorDAO.insertarASubidos(elibro, usuario.getName());
    }

    public static void anadirAutor(Usuario usuario) throws Exception {
        Autor autor = new Autor(usuario);
        autorDAO.insertar(autor);
    }
}
