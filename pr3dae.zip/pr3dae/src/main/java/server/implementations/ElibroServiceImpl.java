/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.implementations;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import org.springframework.web.bind.annotation.RestController;
import server.classes.Elibro;
import server.daos.ElibroDAO;
import server.dtos.ElibroDTO;
import server.auxs.EstadoDeLibro;
import server.exceptions.LibroNoExiste;
import server.auxs.EstadoDeLibro.Estado;
import static server.implementations.RevisorServiceImpl.buscarLibrosEnRevision;
import server.interfaces.ElibroService;

/**
 *
 * @author Felipe
 */
@Component
@RestController
@RequestMapping
public class ElibroServiceImpl implements ElibroService {

    protected static ElibroDAO elibroDAO;

    @Autowired
    public void setElibroDAO(ElibroDAO elibroDAO) {
        ElibroServiceImpl.elibroDAO = elibroDAO;
    }

    @Override
    @RequestMapping(value = "/editor/librosNoRevisados", method = GET)
    public List<ElibroDTO> buscaLibrosPorRevisar() throws Exception {
        return toDTO(elibroDAO.buscarPorRevisar());
    }

    @Override
    @RequestMapping(value = "/revisor/libros", method = GET)
    public List<ElibroDTO> buscaLibrosDelRevisor(Principal usuario) throws Exception {
        return toDTO(buscarLibrosEnRevision(usuario.getName()));
    }

    @Override
    @RequestMapping(value = "/editor/librosNoValidados", method = GET)
    public List<ElibroDTO> buscaLibrosPorValidar() throws Exception {
        return toDTO(elibroDAO.buscarPorValidar());
    }

    @Override
    @RequestMapping(value = "/libros/tematica", method = GET)
    public List<ElibroDTO> buscaLibrosTematica() {
        List<ElibroDTO> librosValidos = buscaLibrosTitulo();
        librosValidos.sort((ElibroDTO t, ElibroDTO t1) -> t.getTematica().compareTo(t1.getTematica()));
        return librosValidos;
    }

    @Override
    @RequestMapping(value = "/libros/titulo", method = GET)
    public List<ElibroDTO> buscaLibrosTitulo() {
        return toDTO(elibroDAO.buscarValidados());
    }

    @Override
    @RequestMapping(value = "/libros/tematica/{tematica}", method = GET)
    public List<ElibroDTO> buscaLibrosTematica(@PathVariable("tematica") String tematica) {
        return toDTO(elibroDAO.buscarPorTematica(tematica));
    }

    @Override
    @RequestMapping(value = "/libros/titulo/{titulo}", method = GET, produces = "application/json")
    public List<ElibroDTO> buscaLibrosTitulo(@PathVariable("titulo") String titulo) {
        return toDTO(elibroDAO.buscarPorTitulo(titulo));
    }

    @Override
    @RequestMapping(value = "/libro/{titulo}", method = GET, produces = "application/json")
    public ElibroDTO descargarLibro(@PathVariable("titulo") String titulo) throws Exception {
        ElibroDTO libro = null;
        List<ElibroDTO> coleccion = buscaLibrosTitulo();
        for (ElibroDTO el : coleccion) {
            if (el.getTitulo().equals(titulo)) {
                libro = el;
            }
        }
        if (libro == null) {
            throw new LibroNoExiste();
        }
        return libro;
    }

    public List<ElibroDTO> toDTO(List<Elibro> elibros) {
        List<ElibroDTO> nuevo = new ArrayList<>();
        for (int i = 0; i < elibros.size(); i++) {
            ElibroDTO libro = new ElibroDTO(elibros.get(i).getTematica(), elibros.get(i).getTitulo(),
                    elibros.get(i).getFechaDePublicacion());
            nuevo.add(libro);
        }
        return nuevo;
    }

    public static Elibro buscarLibro(String titulo) throws Exception {
        Elibro libro = elibroDAO.buscar(titulo);
        if (libro == null) {
            throw new LibroNoExiste();
        }
        return libro;
    }

    public static void anadirLibro(Elibro elibro) throws Exception {
        elibroDAO.insertar(elibro);
    }

    public static void setEsRevisado(Elibro elibro) {
        elibro.setEsRevisado(true);
        elibroDAO.actualizar(elibro);
    }

    public static void setEsValido(Elibro elibro) {
        elibro.setEsValido(true);
        elibroDAO.actualizar(elibro);
    }

    public static boolean tieneRevisores(String titulo) {
        return elibroDAO.tieneRevisores(titulo);
    }

    public static List<Integer> buscarNotas(String titulo) {
        return elibroDAO.buscarNotas(titulo);
    }

    public static boolean insertarNota(String titulo, int nota) throws Exception {
        return elibroDAO.insertarNota(titulo, nota);
    }

    @Override
    @RequestMapping(value = "/revisor/aviso", method = GET)
    public List<EstadoDeLibro> obtenerEstadoRevision(Principal usuario) throws Exception {
        List<EstadoDeLibro> paresEnRevision = new ArrayList<>();

        for (ElibroDTO elDTO : toDTO(buscarLibrosEnRevision(usuario.getName()))) {
            Calendar calendar = Calendar.getInstance(), calendar2 = Calendar.getInstance();
            calendar.setTime(elDTO.getFechaDePublicacion());
            calendar2.setTime(elDTO.getFechaDePublicacion());
            calendar.add(Calendar.DAY_OF_YEAR, 23);
            calendar2.add(Calendar.DAY_OF_YEAR, 30);
            Estado estado = Estado.FUERA_PLAZO;
            if (calendar.getTime().before(new Date()) && calendar2.getTime().after(new Date())) {
                estado = Estado.FUERA_PLAZO_EN_1_SEMANA;
            } else if (calendar2.getTime().after(new Date())) {
                estado = Estado.EN_PLAZO;
            }
            paresEnRevision.add(new EstadoDeLibro(elDTO, estado));
        }
        return paresEnRevision;
    }
}
