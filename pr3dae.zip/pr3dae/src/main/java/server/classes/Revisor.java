/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.classes;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Temporal;
import static javax.persistence.TemporalType.DATE;

/**
 *
 * @author Felipe
 */
@Entity
public class Revisor extends Usuario {

    @ManyToMany
    private List<Elibro> librosEnRevision;
    @Temporal(DATE)
    private Date ultimaRevision;

    public Revisor() throws Exception {
        librosEnRevision = new ArrayList<>();
        ultimaRevision = new SimpleDateFormat("dd/MM/yyyy").parse("01/01/0001");
    }

    public Revisor(Usuario usuario) throws Exception {
        super(usuario);
        librosEnRevision = new ArrayList<>();
        ultimaRevision = new SimpleDateFormat("dd/MM/yyyy").parse("01/01/0001");
    }

    /**
     * @return the librosEnRevision
     */
    public List<Elibro> getLibrosEnRevision() {
        return librosEnRevision;
    }

    /**
     * @param librosEnRevision the librosEnRevision to set
     */
    public void setLibrosEnRevision(List<Elibro> librosEnRevision) {
        this.librosEnRevision = librosEnRevision;
    }

    /**
     * @return the ultimaRevision
     */
    public Date getUltimaRevision() {
        return ultimaRevision;
    }

    /**
     * @param ultimaRevision the ultimaRevision to set
     */
    public void setUltimaRevision(Date ultimaRevision) {
        this.ultimaRevision = ultimaRevision;
    }
}
