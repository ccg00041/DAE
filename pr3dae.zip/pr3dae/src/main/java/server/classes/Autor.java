/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.classes;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

/**
 *
 * @author Felipe
 */
@Entity
public class Autor extends Usuario {

    @OneToMany
    private List<Elibro> librosSubidos;

    public Autor() {
        librosSubidos = new ArrayList<>();
    }

    public Autor(Usuario usuario) {
        super(usuario);
        librosSubidos = new ArrayList<>();
    }

    /**
     * @return the librosSubidos
     */
    public List<Elibro> getLibrosSubidos() {
        return librosSubidos;
    }

    /**
     * @param librosSubidos the librosSubidos to set
     */
    public void setLibrosSubidos(List<Elibro> librosSubidos) {
        this.librosSubidos = librosSubidos;
    }
}
