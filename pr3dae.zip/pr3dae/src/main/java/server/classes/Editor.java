/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.classes;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Felipe
 */
public class Editor extends Usuario {

    private List<Elibro> librosValidados;

    public Editor() {
        librosValidados = new ArrayList<>();
    }

    public Editor(Usuario usuario) {
        super(usuario);
        librosValidados = new ArrayList<>();
    }

    /**
     * @return the librosValidados
     */
    public List<Elibro> getLibrosValidados() {
        return librosValidados;
    }

    /**
     * @param librosValidados the librosValidados to set
     */
    public void setLibrosValidados(List<Elibro> librosValidados) {
        this.librosValidados = librosValidados;
    }
}
