/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.classes;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Temporal;
import static javax.persistence.TemporalType.DATE;
import javax.persistence.Version;

/**
 *
 * @author Felipe
 */
@Entity
public class Elibro implements Serializable {

    private boolean esRevisado, esValido;
    private String autor, tematica;
    @Id
    private String titulo;
    @Temporal(DATE)
    private Date fechaDePublicacion;
    @ManyToMany(mappedBy = "librosEnRevision")
    private List<Revisor> revsDelLibro;
    @ElementCollection(targetClass = Integer.class)
    private List<Integer> notas;
    @Version
    int version;
    
    public Elibro() {
        notas = new ArrayList<>();
    }

    /**
     * @return the esRevisado
     */
    public boolean isEsRevisado() {
        return esRevisado;
    }

    /**
     * @param esRevisado the esRevisado to set
     */
    public void setEsRevisado(boolean esRevisado) {
        this.esRevisado = esRevisado;
    }

    /**
     * @return the esValido
     */
    public boolean isEsValido() {
        return esValido;
    }

    /**
     * @param esValido the esValido to set
     */
    public void setEsValido(boolean esValido) {
        this.esValido = esValido;
    }

    /**
     * @return the autor
     */
    public String getAutor() {
        return autor;
    }

    /**
     * @param autor the autor to set
     */
    public void setAutor(String autor) {
        this.autor = autor;
    }

    /**
     * @return the tematica
     */
    public String getTematica() {
        return tematica;
    }

    /**
     * @param tematica the tematica to set
     */
    public void setTematica(String tematica) {
        this.tematica = tematica;
    }

    /**
     * @return the titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @param titulo the titulo to set
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * @return the notas
     */
    public List<Integer> getNotas() {
        return notas;
    }

    /**
     * @param notas the notas to set
     */
    public void setNotas(List<Integer> notas) {
        this.notas = notas;
    }

    /**
     * @return the fechaDePublicacion
     */
    public Date getFechaDePublicacion() {
        return fechaDePublicacion;
    }

    /**
     * @param fechaDePublicacion the fechaDePublicacion to set
     */
    public void setFechaDePublicacion(Date fechaDePublicacion) {
        this.fechaDePublicacion = fechaDePublicacion;
    }

    /**
     * @return the revsDelLibro
     */
    public List<Revisor> getRevsDelLibro() {
        return revsDelLibro;
    }

    /**
     * @param revsDelLibro the revsDelLibro to set
     */
    public void setRevsDelLibro(List<Revisor> revsDelLibro) {
        this.revsDelLibro = revsDelLibro;
    }
}
