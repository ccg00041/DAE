/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.classes;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import static javax.persistence.InheritanceType.TABLE_PER_CLASS;

/**
 *
 * @author Felipe
 */
@Entity
@Inheritance(strategy = TABLE_PER_CLASS)
public class Usuario implements Serializable {

    private boolean esAutor, esRevisor, esEditor;
    private String nombreCompleto, password;
    @Id
    private String nick;

    public Usuario() {
    }

    public Usuario(Usuario usuario) {
        esAutor = usuario.esAutor;
        esRevisor = usuario.esRevisor;
        esEditor = usuario.esEditor;
        nombreCompleto = usuario.nombreCompleto;
        nick = usuario.nick;
        password = usuario.password;
    }

    /**
     * @return the esAutor
     */
    public boolean isEsAutor() {
        return esAutor;
    }

    /**
     * @param esAutor the esAutor to set
     */
    public void setEsAutor(boolean esAutor) {
        this.esAutor = esAutor;
    }

    /**
     * @return the esRevisor
     */
    public boolean isEsRevisor() {
        return esRevisor;
    }

    /**
     * @param esRevisor the esRevisor to set
     */
    public void setEsRevisor(boolean esRevisor) {
        this.esRevisor = esRevisor;
    }

    /**
     * @return the esEditor
     */
    public boolean isEsEditor() {
        return esEditor;
    }

    /**
     * @param esEditor the esEditor to set
     */
    public void setEsEditor(boolean esEditor) {
        this.esEditor = esEditor;
    }

    /**
     * @return the nombreCompleto
     */
    public String getNombreCompleto() {
        return nombreCompleto;
    }

    /**
     * @param nombreCompleto the nombreCompleto to set
     */
    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    /**
     * @return the nick
     */
    public String getNick() {
        return nick;
    }

    /**
     * @param nick the nick to set
     */
    public void setNick(String nick) {
        this.nick = nick;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
