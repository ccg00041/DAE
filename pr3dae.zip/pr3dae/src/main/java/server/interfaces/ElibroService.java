/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.interfaces;

import java.security.Principal;
import java.util.List;
import server.dtos.ElibroDTO;
import server.auxs.EstadoDeLibro;

/**
 *
 * @author Felipe
 */
public interface ElibroService {

    // Método para los editores
    public List<ElibroDTO> buscaLibrosPorRevisar() throws Exception;

    // Método para los revisores
    public List<ElibroDTO> buscaLibrosDelRevisor(Principal usuario) throws Exception;

    // Método para los editores
    public List<ElibroDTO> buscaLibrosPorValidar() throws Exception;

    // Método para el público
    public List<ElibroDTO> buscaLibrosTematica();

    // Método para el público
    public List<ElibroDTO> buscaLibrosTitulo();

    // Método para el público
    public List<ElibroDTO> buscaLibrosTematica(String tematica);

    // Método para el público
    public List<ElibroDTO> buscaLibrosTitulo(String titulo);

    // Método para el público
    public ElibroDTO descargarLibro(String titulo) throws Exception;
    
    public List<EstadoDeLibro> obtenerEstadoRevision(Principal usuario) throws Exception;
}
