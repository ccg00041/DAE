/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.interfaces;

import server.dtos.ElibroDTO;
import server.dtos.RevisorDTO;

/**
 *
 * @author Felipe
 */
public interface EditorService {

    public void validarLibro(ElibroDTO eldto) throws Exception;

    public RevisorDTO[] asignarRevisores(ElibroDTO eldto) throws Exception;
}
