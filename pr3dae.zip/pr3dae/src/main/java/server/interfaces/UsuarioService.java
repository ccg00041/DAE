/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.interfaces;

import java.security.Principal;
import server.dtos.UsuarioDTO;

/**
 *
 * @author Felipe
 */
public interface UsuarioService {

    public UsuarioDTO identifica(Principal principal) throws Exception;

    public void registro(UsuarioDTO udto) throws Exception;
}
