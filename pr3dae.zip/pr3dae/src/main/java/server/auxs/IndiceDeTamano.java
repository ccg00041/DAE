/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.auxs;

/**
 *
 * @author carol
 */
public class IndiceDeTamano {

    private int indice;
    private Integer tamano;

    public IndiceDeTamano(int indice, Integer tamano) {
        this.indice = indice;
        this.tamano = tamano;
    }

    /**
     * @return the indice
     */
    public int getIndice() {
        return indice;
    }

    /**
     * @param indice the indice to set
     */
    public void setIndice(int indice) {
        this.indice = indice;
    }

    /**
     * @return the tamano
     */
    public Integer getTamano() {
        return tamano;
    }

    /**
     * @param tamano the tamano to set
     */
    public void setTamano(Integer tamano) {
        this.tamano = tamano;
    }
}
