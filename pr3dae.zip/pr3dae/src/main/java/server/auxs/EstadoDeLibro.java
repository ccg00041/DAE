/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.auxs;

import server.dtos.ElibroDTO;

/**
 *
 * @author carol
 */
public class EstadoDeLibro {

    public enum Estado {
        EN_PLAZO, FUERA_PLAZO_EN_1_SEMANA, FUERA_PLAZO
    }

    private ElibroDTO elDTO;
    private Estado estado;

    public EstadoDeLibro(ElibroDTO elDTO, Estado estado) {
        this.elDTO = elDTO;
        this.estado = estado;
    }

    /**
     * @return the elDTO
     */
    public ElibroDTO getElDTO() {
        return elDTO;
    }

    /**
     * @param elDTO the elDTO to set
     */
    public void setElDTO(ElibroDTO elDTO) {
        this.elDTO = elDTO;
    }

    /**
     * @return the estado
     */
    public Estado getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(Estado estado) {
        this.estado = estado;
    }
}
