/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.daos;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import static org.springframework.transaction.annotation.Propagation.REQUIRED;
import static org.springframework.transaction.annotation.Propagation.SUPPORTS;
import org.springframework.transaction.annotation.Transactional;
import server.auxs.IndiceDeFecha;
import server.auxs.IndiceDeTamano;
import server.classes.Elibro;
import server.classes.Revisor;
import server.exceptions.RevisorYaExiste;
import static server.implementations.RevisorServiceImpl.getRevisor;

/**
 *
 * @author admin
 */
@Repository
@Transactional(propagation = REQUIRED, readOnly = false)
public class RevisorDAO {

    @PersistenceContext
    public EntityManager em;

    @Transactional(propagation = SUPPORTS, readOnly = true)
    public Revisor buscar(String nick) {
        return em.find(Revisor.class, nick);
    }

    @Transactional(propagation = SUPPORTS, readOnly = true)
    public List<Revisor> buscarTodos() {
        try {
            return em.createQuery("SELECT R FROM Revisor R", Revisor.class).getResultList();
        } catch (Exception e) {
            return null;
        }
    }

    @Transactional(propagation = SUPPORTS, readOnly = true)
    public List<Elibro> buscarLibrosEnRevision(String nick) {
        return new ArrayList<>(buscar(nick).getLibrosEnRevision());
    }

    @Transactional(propagation = SUPPORTS, readOnly = true)
    public void cargarListasDeCandidatos(List<IndiceDeTamano> sizes, List<IndiceDeFecha> dates) {
        int i = 0;
        for (Revisor actual : buscarTodos()) {
            sizes.add(new IndiceDeTamano(i, actual.getLibrosEnRevision().size()));
            dates.add(new IndiceDeFecha(i, actual.getUltimaRevision()));
            i++;
        }
    }

    @Transactional(propagation = SUPPORTS, readOnly = true)
    public Revisor[] cargarListaDeRevisores(List<IndiceDeTamano> sizes, List<IndiceDeFecha> dates) {
        Revisor[] rsores = new Revisor[3];
        for (int x = 0; x < 3; x++) {
            if (new Random().nextBoolean()) {
                rsores[x] = getRevisor(dates.get(0).getIndice());
                sizes.remove(new IndiceDeTamano(dates.get(0).getIndice(), rsores[x].getLibrosEnRevision().size()));
                dates.remove(0);
            } else {
                rsores[x] = getRevisor(sizes.get(0).getIndice());
                dates.remove(new IndiceDeFecha(sizes.get(0).getIndice(), rsores[x].getUltimaRevision()));
                sizes.remove(0);
            }
        }
        return rsores;
    }

    @Transactional(rollbackFor = RevisorYaExiste.class)
    public void insertar(Revisor revisor) throws Exception {
        try {
            em.clear();
            em.persist(revisor);
            em.flush();
        } catch (Exception e) {
            throw new RevisorYaExiste();
        }
    }

    public boolean insertarAEnRevision(Elibro elibro, String nick) {
        Revisor revisor = buscar(nick);
        boolean insertado = revisor.getLibrosEnRevision().add(elibro);
        actualizar(revisor);
        return insertado;
    }

    public void actualizar(Revisor revisor) {
        em.merge(revisor);
    }

    public void eliminar(Revisor revisor) {
        em.remove(em.merge(revisor));
    }

    public void eliminarDeEnRevision(Elibro elibro, String nick) {
        Revisor revisor = buscar(nick);
        new ArrayList<>(revisor.getLibrosEnRevision()).stream().filter((el) -> (el.getTitulo().equals(elibro.getTitulo()))).forEachOrdered((el) -> {
            revisor.getLibrosEnRevision().remove(el);
        });
        revisor.setUltimaRevision(new Date());
        actualizar(revisor);
    }
}
