/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.daos;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import static org.springframework.transaction.annotation.Propagation.REQUIRED;
import static org.springframework.transaction.annotation.Propagation.SUPPORTS;
import org.springframework.transaction.annotation.Transactional;
import server.classes.Autor;
import server.classes.Elibro;
import server.exceptions.AutorYaExiste;

/**
 *
 * @author admin
 */
@Repository
@Transactional(propagation = REQUIRED, readOnly = false)
public class AutorDAO {

    @PersistenceContext
    EntityManager em;

    @Transactional(propagation = SUPPORTS, readOnly = true)
    public Autor buscar(String nick) {
        return em.find(Autor.class, nick);
    }

    @Transactional(rollbackFor = AutorYaExiste.class)
    public void insertar(Autor autor) throws Exception {
        try {
            em.clear();
            em.persist(autor);
            em.flush();
        } catch (Exception e) {
            throw new AutorYaExiste();
        }
    }

    public boolean insertarASubidos(Elibro elibro, String nick) {
        Autor autor = buscar(nick);
        boolean subido = autor.getLibrosSubidos().add(elibro);
        actualizar(autor);
        return subido;
    }

    public void actualizar(Autor autor) {
        em.merge(autor);
    }

    public void eliminar(Autor autor) {
        em.remove(em.merge(autor));
    }
}
