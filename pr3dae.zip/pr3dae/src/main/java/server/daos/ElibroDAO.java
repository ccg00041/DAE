/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.daos;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.PersistenceContext;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;
import static org.springframework.transaction.annotation.Propagation.REQUIRED;
import static org.springframework.transaction.annotation.Propagation.SUPPORTS;
import org.springframework.transaction.annotation.Transactional;
import server.classes.Elibro;
import server.exceptions.LibroYaExiste;
import server.exceptions.AsignacionDeNotaProhibida;

/**
 *
 * @author admin
 */
@Repository
@Transactional(propagation = SUPPORTS, readOnly = true)
public class ElibroDAO {

    @PersistenceContext
    EntityManager em;

    public Elibro buscar(String titulo) {
        return em.find(Elibro.class, titulo);
    }

    public List<Elibro> buscarPorRevisar() {
        try {
            return em.createQuery("SELECT E FROM Elibro E WHERE E.esRevisado = false", Elibro.class).getResultList();
        } catch (Exception e) {
            return null;
        }
    }

    public List<Elibro> buscarPorValidar() {
        try {
            return em.createQuery("SELECT E FROM Elibro E WHERE E.esValido = false", Elibro.class).getResultList();
        } catch (Exception e) {
            return null;
        }
    }

    public List<Elibro> buscarValidados() {
        try {
            return em.createQuery("SELECT E FROM Elibro E WHERE E.esValido = true", Elibro.class).getResultList();
        } catch (Exception e) {
            return null;
        }
    }

    @Cacheable(value = "libros_tematica")
    public List<Elibro> buscarPorTematica(String tematica) {
        try {
            return em.createQuery("SELECT E FROM Elibro E WHERE E.esValido = true AND E.tematica = :TEMATICA", Elibro.class)
                    .setParameter("TEMATICA", tematica).getResultList();
        } catch (Exception e) {
            return null;
        }
    }

    public List<Elibro> buscarPorTitulo(String titulo) {
        try {
            return em.createQuery("SELECT E FROM Elibro E WHERE E.esValido = true AND E.titulo = :TITULO", Elibro.class)
                    .setParameter("TITULO", titulo).getResultList();
        } catch (Exception e) {
            return null;
        }
    }

    public List<Integer> buscarNotas(String titulo) {
        return new ArrayList<>(buscar(titulo).getNotas());
    }

    public boolean tieneRevisores(String titulo) {
        return !buscar(titulo).getRevsDelLibro().isEmpty();
    }

    @Transactional(propagation = REQUIRED,
            rollbackFor = LibroYaExiste.class, readOnly = false)
    public void insertar(Elibro elibro) throws Exception {
        try {
            em.persist(elibro);
            em.flush();
        } catch (Exception e) {
            throw new LibroYaExiste();
        }
    }

//    @Transactional(readOnly = false)
    @Transactional(propagation = REQUIRED,
            rollbackFor = AsignacionDeNotaProhibida.class, readOnly = false)
    public boolean insertarNota(String titulo, int nota) throws Exception {
        try {
            Elibro elibro = buscar(titulo);
            em.lock(elibro, LockModeType.OPTIMISTIC);
            boolean subida = elibro.getNotas().add(nota);
            if (elibro.getNotas().size() == 3) {
                elibro.setEsRevisado(true);
            }
            actualizar(elibro);
            return subida;
        } catch (Exception e) {
            throw new AsignacionDeNotaProhibida();
        }
    }

    @Transactional(propagation = REQUIRED, readOnly = false)
    public void actualizar(Elibro elibro) {
        em.merge(elibro);
    }

    @Transactional(propagation = REQUIRED, readOnly = false)
    public void eliminar(Elibro elibro) {
        em.remove(em.merge(elibro));
    }
}
