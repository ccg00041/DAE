/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 *
 * @author admin
 */
@Configuration
@EnableWebSecurity
public class ConfiguracionDeSeguridad extends WebSecurityConfigurerAdapter {

    @Autowired
    ServicioDeUsuarios identificacion;

    @Override
    public void configure(AuthenticationManagerBuilder auth) throws Exception {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        auth.userDetailsService(identificacion).passwordEncoder(encoder);
        auth.inMemoryAuthentication().withUser("editor").roles("EDITOR")
                .password("$2a$04$XNyzaIl4snu1mfDDFXUpmet6Ei.kLRIzoV3VphD2w3BEMwzgTnkD6")
                .and().passwordEncoder(encoder);
    }

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity.csrf().disable();
        httpSecurity.httpBasic();
        httpSecurity.authorizeRequests().antMatchers("/editor/**").hasAnyRole("EDITOR");
        httpSecurity.authorizeRequests().antMatchers("/revisor/**").hasAnyRole("REVISOR");
        httpSecurity.authorizeRequests().antMatchers("/autor/**").hasAnyRole("AUTOR");
        httpSecurity.authorizeRequests().antMatchers(HttpMethod.GET, "/usuario").authenticated();
        httpSecurity.authorizeRequests().antMatchers("/**").permitAll();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
